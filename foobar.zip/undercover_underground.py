dictFactorial = {}
def factorial(num):
    if num < 2: return 1
    if num not in dictFactorial: dictFactorial[num] = factorial(num - 1) * num
    return dictFactorial[num]

dictCombination = {}
def combination(n,k):
    if n == k and k == 0:
        return 1
    if n == 0:
        return 0
    if (n,k) not in dictCombination:
        dictCombination[(n,k)] = int(factorial(n) / (factorial(k) * factorial(n - k)))
        dictCombination[(n,n - k)] = dictCombination[(n,k)]
    return dictCombination[(n,k)]

#def answer(n,k):
#    t = int((n * (n - 1)) / 2)
#    ret = 0
#    if t >= k:
#        ret = combination(t,k)
#        for i in range(n - 1,1,-1):
#            x = int((i * (i - 1)) / 2)
#            if x >= k:
#                ret -= combination(x,k) * combination(n,i)
#    return ret
dictA = {}
def answer(n,k):
    if (n,k) not in dictA:
        t = combination(n,2)
        ret = combination(t,k)
        if k < combination(n - 1,2) + 1:
            for i in range(1,n):
                x = combination(n - 1, i - 1) 
                y = min(combination(i,2), k) 
                for j in range(i - 1, y + 1): 
                    ret -= x * combination(combination(n - i,2),k - j) * answer(i, j) 
        dictA[(n,k)] = ret
    return dictA[(n,k)]

def main():
    for i in range(1,9):
        for j in range(i - 1,combination(i,2) + 1):
            print(str(answer(i,j)))
if __name__ == "__main__":
    main()